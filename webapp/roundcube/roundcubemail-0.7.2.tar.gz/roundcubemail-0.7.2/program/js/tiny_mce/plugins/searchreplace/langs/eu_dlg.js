tinyMCE.addI18n('eu.searchreplace_dlg',{
searchnext_desc:"Berriz bilatu",
notfound:"Bilaketa bukatu da. Bilatutakoa ez da aurkitu.",
search_title:"Bilatu",
replace_title:"Bilatu/Ordezkatu",
allreplaced:"Bilatutakoaren agerpen guztiak ordezkatu dira.",
findwhat:"Zer bilatu",
replacewith:"Zerekin ordezkatu",
direction:"Norabidea",
up:"Gorantz",
down:"Beherantz",
mcase:"Maiuskulak eta minuskulak kontuan hartu",
findnext:"Hurrengoa",
replace:"Ordezkatu",
replaceall:"Ordezkatu guztiak"
});